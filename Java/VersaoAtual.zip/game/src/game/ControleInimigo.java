/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import java.util.LinkedList;
import jplay.Scene;

/**
 *
 * @author hallef-PC
 */
public class ControleInimigo {

    static LinkedList<inimigo_comum> inimigos = new LinkedList<>();
    public static inimigo_comum ini;
    private int dificuldade = 500;
    int cont = 0;

    public void addInimigo(Scene cena) {
        ini = new inimigo_comum();
        inimigos.addFirst(ini);
        cena.addOverlay(ini);
    }

    public void inimigo(Scene cena) {
        if (cont < dificuldade) {
            cont++;
        } else {
            addInimigo(cena);
            cont = 0;
        }
        run();
    }
    
    public void run(){
        int j= 0;
        for(int i = 0; i < inimigos.size(); i++){
            inimigos.get(i).mover();
            
//            if(!inimigos.get(j).mover()){
//                inimigo_comum ini_aux = inimigos.get(j);
//                if(inimigos.remove(ini_aux)){
//                    j++;
//                }
//            }
        }
        
    }

}
