/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import jplay.Keyboard;
import jplay.Scene;
import jplay.URL;
import jplay.Window;

public class cenario {
    private Window janela;
    private Scene cena;
    private Jogador jogador;
    private inimigo_comum alien;
    private ControleInimigo control;
    private Keyboard teclado;
    
    public cenario(Window window){
        janela = window;
        cena = new Scene();
        cena.loadFromFile(URL.scenario("cenario.scn"));
        jogador = new Jogador(300,300);
        alien = new inimigo_comum();
        teclado = janela.getKeyboard();
        control = new ControleInimigo();
        som.play("trilha.wav");
        run();
    }
    
    private void run(){
        while(true){
            cena.draw();
            jogador.draw();
            jogador.mover(janela);
            jogador.atirar(janela, cena, teclado);
            alien.draw();
            control.inimigo(cena);
            janela.update();
        }
    }
}
