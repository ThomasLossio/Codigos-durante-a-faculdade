/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import java.util.Random;
import jplay.Keyboard;
import jplay.Sprite;
import jplay.URL;
import jplay.Window;

/**
 *
 * @author hallef-PC
 */
public class inimigo_comum extends Sprite{
    private double velocidade = 0.3;
    private int direcao = 3;
    
    public int gerarPosY(){
        Random gerador = new Random();
        int valor = gerador.nextInt(400)+50;
        return valor;
    }
    
    public inimigo_comum() {
        super(URL.sprite("alienInimigo.png"),2);
        this.x = 800;
        this.y = gerarPosY();
        //this.setTotalDuration(2000);
    }
    
    public boolean mover(){
        if(this.x <= 80){
            return false;
        }else{
            this.x -= velocidade;
            setSequence(0, 2);
            update();
            return true;
        }
    }
    
    
    
}

