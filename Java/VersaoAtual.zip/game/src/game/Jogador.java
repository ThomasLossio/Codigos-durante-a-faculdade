/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import com.sun.glass.events.KeyEvent;
import jplay.Keyboard;
import jplay.Scene;
import jplay.Sprite;
import jplay.URL;
import jplay.Window;


public class Jogador extends Sprite{

    private double velocidade = 0.5;
    private int direcao = 3;
    private Keyboard teclado;
    private boolean movendo = false;
    private int cont = 0;
    
    public Jogador(int x, int y) {
        super(URL.sprite("navedon.png"),2);
        this.x = 15;
        this.y = y;
        this.setTotalDuration(2000);
        
    }
    ControleTiro tiros =  new ControleTiro();
    public void atirar(Window janela, Scene cena, Keyboard teclado){
        if(teclado.keyDown(Keyboard.SPACE_KEY)){
            tiros.addTiro(x, y + 20, height, cena);
        
        }
        tiros.run();
    }
    
    public void mover(Window janela){
        if(teclado == null){
            teclado = janela.getKeyboard();
        }
        
        if(teclado.keyDown(Keyboard.UP_KEY)){
            if(this.y > 80){
                   this.y -= velocidade;
               }
            setSequence(0, 2);
            movendo = true;
            }
        else if(teclado.keyDown(Keyboard.DOWN_KEY)){
            if(this.y < janela.getHeight()-160){
               this.y += velocidade;
           }
            setSequence(0, 2);
            movendo = true;
        }
        else if(teclado.keyDown(Keyboard.LEFT_KEY)){
            if(this.x > 15){
                this.x -= velocidade;
            }
            setSequence(0, 2);
            movendo = true;
        
        }
        else if(teclado.keyDown(Keyboard.RIGHT_KEY)){
            if(this.x < (janela.getWidth()/2)-80){
                this.x += velocidade;
            }
            setSequence(0, 2);
            movendo = true;
        }
        
        if(cont < 50){
            cont++;
        }else{
            update();
            cont = 0;
        }
    }

    

    
    
}
