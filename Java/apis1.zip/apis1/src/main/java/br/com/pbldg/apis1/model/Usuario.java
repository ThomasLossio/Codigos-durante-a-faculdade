package br.com.pbldg.apis1.model;

public class Usuario {

}
