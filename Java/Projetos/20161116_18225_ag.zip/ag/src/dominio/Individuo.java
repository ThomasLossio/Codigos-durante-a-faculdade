package dominio;

import java.util.Random;
import operacao.Algoritimo;

/**
 * Classe que define um indivíduo
 *
 * @author pcollares
 */
public class Individuo {

    private int gene[] = new int[Algoritimo.N];
    private double aptidao;
    private int geracao;

    public Individuo(int[] gene) {
        this.gene = gene;
        aptidao = CalculaFitness();
    }

    public Individuo() {

        
        for (int i = 0; i < gene.length; i++) {
            int g = geneAleatorio();
            this.gene[i] = g;
        }
        aptidao = CalculaFitness();
    }

    private int CalculaFitness(){
        int soma=0;
        if (this.gene[0]==0){ soma++;}
        if (this.gene[1]==8){ soma++;}
        if (this.gene[2]==0){ soma++;}
        if (this.gene[3]==4){ soma++;}
        if (this.gene[4]==7){ soma++;}
        if (this.gene[5]==8){ soma++;}                        
        soma=100-(10*soma);
     return soma;
    }
    
    public void aplicaMutacao(double aptidaoMedia) {
        Random r = new Random();
        double taxaMutacao = Algoritimo.getTaxaDeMutacao();

        //Melhores indivíduos tem menos chances de sofrerem mutação
        if (aptidao < aptidaoMedia) {
            taxaMutacao = taxaMutacao / 10;
        }

        if (r.nextDouble() <= taxaMutacao) {
            r = new Random();
            this.gene[r.nextInt(gene.length)] = geneAleatorio();
            aptidao =CalculaFitness();
        }
    }

    public int[] getGene() {
        return gene;
    }

    public double getAptidao() {
        return aptidao;
    }

    private int geneAleatorio() {
        Random r = new Random();
        int valor = r.nextInt(10);
        return valor;
    }

    public int getGeracao() {
        return geracao;
    }

    public void setGeracao(int geracao) {
        this.geracao = geracao;
    }

    @Override
    public String toString() {
        String s = "[ ";
        for (int i = 0; i < gene.length; i++) {
            s += gene[i] + " ";
        }
        s += " ]";
        return s;
    }
}